package com.upload.csvUpload.services;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.upload.csvUpload.CsvHelper;
import com.upload.csvUpload.CsvHelperLoan;
import com.upload.csvUpload.entites.CsvData;
import com.upload.csvUpload.entites.LoanDetails;
import com.upload.csvUpload.repository.CsvLoanRepository;
import com.upload.csvUpload.repository.CsvRepository;

@Service
public class CsvService {
	@Autowired
	  CsvRepository repository;
	@Autowired
	  CsvLoanRepository csvLoanRepository;

	  public void save(MultipartFile file) {
	    try {
	      List<CsvData> tutorials = CsvHelper.csvToTutorials(file.getInputStream());
	      repository.saveAll(tutorials);
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store csv data: " + e.getMessage());
	    }
}
	  public void saveLoan(MultipartFile file) {
		    try {
		      List<LoanDetails> tutorials = CsvHelperLoan.csvToTutorials(file.getInputStream());
		      csvLoanRepository.saveAll(tutorials);
		    } catch (IOException e) {
		      throw new RuntimeException("fail to store csv data: " + e.getMessage());
		    }
	}
}
