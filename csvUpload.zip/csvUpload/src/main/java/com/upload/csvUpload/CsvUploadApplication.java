package com.upload.csvUpload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvUploadApplication.class, args);
	}

}
