package com.upload.csvUpload.entites;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CsvData {
	@Id
	private int beneficiary_id;
	private String beneficiary_name;
	private String  beneficary_type;
	private String  company_name;
	private String  registration_number;
	private String category;
	private String gender;
	private int pincode;
	public int getBeneficiary_id() {
		return beneficiary_id;
	}
	public void setBeneficiary_id(int beneficiary_id) {
		this.beneficiary_id = beneficiary_id;
	}
	public String getBeneficiary_name() {
		return beneficiary_name;
	}
	public void setBeneficiary_name(String beneficiary_name) {
		this.beneficiary_name = beneficiary_name;
	}
	public String getBeneficary_type() {
		return beneficary_type;
	}
	public void setBeneficary_type(String beneficary_type) {
		this.beneficary_type = beneficary_type;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getRegistration_number() {
		return registration_number;
	}
	public void setRegistration_number(String registration_number) {
		this.registration_number = registration_number;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public CsvData(int beneficiary_id, String beneficiary_name, String beneficary_type, String company_name,
			String registration_number, String category, String gender, int pincode) {
		super();
		this.beneficiary_id = beneficiary_id;
		this.beneficiary_name = beneficiary_name;
		this.beneficary_type = beneficary_type;
		this.company_name = company_name;
		this.registration_number = registration_number;
		this.category = category;
		this.gender = gender;
		this.pincode = pincode;
	}
	public CsvData() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CsvData [beneficiary_id=" + beneficiary_id + ", beneficiary_name=" + beneficiary_name
				+ ", beneficary_type=" + beneficary_type + ", company_name=" + company_name + ", registration_number="
				+ registration_number + ", category=" + category + ", gender=" + gender + ", pincode=" + pincode + "]";
	}

}
