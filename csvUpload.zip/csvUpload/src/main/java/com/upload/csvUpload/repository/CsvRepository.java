package com.upload.csvUpload.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.upload.csvUpload.entites.CsvData;

@Repository
public interface CsvRepository extends JpaRepository<CsvData, Integer>{

}
