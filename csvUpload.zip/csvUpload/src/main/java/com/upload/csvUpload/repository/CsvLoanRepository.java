package com.upload.csvUpload.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.upload.csvUpload.entites.LoanDetails;

@Repository
public interface CsvLoanRepository extends JpaRepository<LoanDetails, Integer>{

}
