package com.upload.csvUpload;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.QuoteMode;
import org.springframework.web.multipart.MultipartFile;

import com.upload.csvUpload.entites.CsvData;
import com.upload.csvUpload.entites.LoanDetails;

public class CsvHelperLoan {
	public static String TYPE = "text/csv";
	static String[] HEADERs = { "Id", "Title", "Description", "Published" };
	public static boolean hasCSVFormat(MultipartFile file) {
	    if (TYPE.equals(file.getContentType())
	    		|| file.getContentType().equals("application/vnd.ms-excel")) {
	      return true;
	    }

	    return false;
	  }
	
	public static List<LoanDetails> csvToTutorials(InputStream is) {
	    try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
	        CSVParser csvParser = new CSVParser(fileReader,
	            CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

	      List<LoanDetails> developerTutorialList = new ArrayList<>();

	      Iterable<CSVRecord> csvRecords = csvParser.getRecords();

	      for (CSVRecord csvRecord : csvRecords) {
	    	  LoanDetails developerTutorial = new LoanDetails(
	              Integer.parseInt(csvRecord.get("application_id")),
	              Integer.parseInt(csvRecord.get("beneficiary_id")),
	              csvRecord.get("lending_institution_name"),
	              csvRecord.get("lending_institution_type"),
	              csvRecord.get("lending_institution_branch_name"),
	              csvRecord.get("ifsc_code"),
	              Integer.parseInt(csvRecord.get("lending_institution_branch_state_code")),
	              csvRecord.get("lending_institution_branch_state"),
	              Integer.parseInt(csvRecord.get("lending_institution_branch_district_code")),
	              csvRecord.get("lending_institution_branch_district"),
	              csvRecord.get("project_type_selected_by_beneficiary"),
	              Integer.parseInt(csvRecord.get("project_address_state_code")),
	              csvRecord.get("project_address_state"),
	              Integer.parseInt(csvRecord.get("project_address_district_code")),
	              csvRecord.get("project_address_district"),
	              csvRecord.get("approval_date"),
	              csvRecord.get("loan_status"),
	              Integer.parseInt(csvRecord.get("approved_amount_aif")),
	              Integer.parseInt(csvRecord.get("approved_amount_total")),
	              Integer.parseInt(csvRecord.get("is_loan_npa")),
	              csvRecord.get("loan_account_number"),
	              Integer.parseInt(csvRecord.get("is_cgtmse"))
	            );

	    	  developerTutorialList.add(developerTutorial);
	      }

	      return developerTutorialList;
	    } catch (IOException e) {
	      throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
	    }
	  }
	
	public static ByteArrayInputStream tutorialsToCSV(List<LoanDetails> developerTutorialList) {
	    final CSVFormat format = CSVFormat.DEFAULT.withQuoteMode(QuoteMode.MINIMAL);

	    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
	        CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
	      for (LoanDetails developerTutorial : developerTutorialList) {
	        List<String> data = Arrays.asList(
	              String.valueOf(developerTutorial.getApplication_id()),
	              String.valueOf(developerTutorial.getBeneficiary_id()),
	              developerTutorial.getLending_institution_name(),
	              developerTutorial.getLending_institution_type(),
	              developerTutorial.getLending_institution_branch_name(),
	              developerTutorial.getIfsc_code(),
	              String.valueOf(developerTutorial.getLending_institution_branch_state_code()),
	              developerTutorial.getLending_institution_branch_state(),
	              String.valueOf(developerTutorial.getLending_institution_branch_district_code()),
	              developerTutorial.getLending_institution_branch_district(),
	              developerTutorial.getProject_type_selected_by_beneficiary(), 
	              String.valueOf(developerTutorial.getProject_address_state_code()),
	              developerTutorial.getProject_address_state(),
	              String.valueOf(developerTutorial.getProject_address_district_code()),
	              developerTutorial.getProject_address_district(),
	              developerTutorial.getApproval_date(),
	              developerTutorial.getLoan_status(),
	              String.valueOf(developerTutorial.getApproved_amount_aif()),
	              String.valueOf(developerTutorial.getApproved_amount_total()),
	              String.valueOf(developerTutorial.getIs_loan_npa()),
	              developerTutorial.getLoan_account_number(),
	              String.valueOf(developerTutorial.getIs_cgtmse()));

	        csvPrinter.printRecord(data);
	      }

	      csvPrinter.flush();
	      return new ByteArrayInputStream(out.toByteArray());
	    } catch (IOException e) {
	      throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
	    }
	  }

}
