package com.upload.csvUpload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
